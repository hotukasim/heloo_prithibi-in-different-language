s =: 'Hello Prithibi'
s