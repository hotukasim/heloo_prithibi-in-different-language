using System;
class Program { static void Main() { Console.WriteLine("Hello Prithibi"); } }